#python3 dataloader/semseg/process_belhouse3d.py --config './dataloader/semseg/process_belhouse3d_iid.yaml'
python3 dataloader/semseg/process_belhouse3d.py --config './dataloader/semseg/process_belhouse3d_ood.yaml'
